# Q1. Write a MIPS assembly program that loads two 32-bit integers and Performs the
# following operations:
# (i)
# o Bitwise AND
# o Bitwise OR
# o Bitwise XOR
# o Bitwise NOR
# (ii) Stores the results in registers $t2, $t3, $t4, and $t5 respectively.
# (iii)Display all results in hexadecimal format.
# Instructions to be used: and, or, xor, nor, li, move, syscall

.data
    num1:       .word   12345678
    num2:       .word   87654321

    msg_and:    .asciiz "\nBitwise AND result: "
    msg_or:     .asciiz "\nBitwise OR  result: "
    msg_xor:    .asciiz "\nBitwise XOR result: "
    msg_nor:    .asciiz "\nBitwise NOR result: "

.text
.globl main

main:
    lw  $t0, num1
    lw  $t1, num2

    and $t2, $t0, $t1
    or  $t3, $t0, $t1
    xor $t4, $t0, $t1
    nor $t5, $t0, $t1

    li  $v0, 4
    la  $a0, msg_and
    syscall

    li  $v0, 34
    move $a0, $t2
    syscall

    li  $v0, 4
    la  $a0, msg_or
    syscall

    li  $v0, 34
    move $a0, $t3
    syscall

    li  $v0, 4
    la  $a0, msg_xor
    syscall

    li  $v0, 34
    move $a0, $t4
    syscall

    li  $v0, 4
    la  $a0, msg_nor
    syscall

    li  $v0, 34
    move $a0, $t5
    syscall

    li  $v0, 10
    syscall