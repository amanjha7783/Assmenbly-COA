
# Q2. Write a MIPS program that takes a number N = 25 stored in a register.
# 1. Performs:
# o Logical left shift by 2 bits
# o Logical right shift by 1 bit
# 2. Prints the original number and the shifted results.
# Instructions to be used: sll, srl

.data
    msg_orig:   .asciiz "Original Number: "
    msg_sll:    .asciiz "\nLeft Shift (<< 2): "
    msg_srl:    .asciiz "\nRight Shift (>> 1): "

.text
.globl main

main:
    
    li  $t0, 25    
             
    li  $v0, 4              
    la  $a0, msg_orig
    syscall

    li  $v0, 1              
    move $a0, $t0          
    syscall

    
    
    sll $t1, $t0, 2         
    li  $v0, 4              
    la  $a0, msg_sll
    syscall

    li  $v0, 1              
    move $a0, $t1           
    syscall

    
    srl $t2, $t0, 1         

    li  $v0, 4             
    la  $a0, msg_srl
    syscall

    li  $v0, 1              
    move $a0, $t2           
    syscall

  
    li  $v0, 10             
    syscall